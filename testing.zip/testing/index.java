package testing;

public class index {
    public static void main(String[] args) {
        Interface i = new Interface();
    }
    
}
